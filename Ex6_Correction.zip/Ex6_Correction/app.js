"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var book_1 = require("./book");
var book = new book_1.Book;
book.name = "L'île Mistérieuse";
console.log(book.name); // affiche L'île Mistérieuse
