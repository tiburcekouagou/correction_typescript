
import { Book } from './book';

let book = new Book;

book.name = "L'île Mistérieuse";

console.log(book.name); // affiche L'île Mistérieuse